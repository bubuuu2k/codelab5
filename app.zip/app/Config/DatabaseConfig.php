<?php

namespace app\Config;

class DataBaseConfig
{
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "web";
    public $port = 3306;
}